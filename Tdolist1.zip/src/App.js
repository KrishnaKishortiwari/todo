import React from 'react'
import Testtodo from './component/todoProject/testtodo';

const App = () => {
  return (
    <>
     <Testtodo />
    </>
  )
}

export default App
